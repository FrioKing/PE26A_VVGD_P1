﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PE26A_VVGD_P1
{
    public partial class DlgPrincipal : Form
    {
        public DlgPrincipal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Resultado = DialogResult.Yes;
            //DeCLARAR VARIABLE, Inicialisamos en yes
            //Comentario epico de una sola linea
            MessageBox.Show("No se pudo conectar a la base de datos","ERROR",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            /*Comentario epico
             de varias lineas*/

            if (Resultado == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
