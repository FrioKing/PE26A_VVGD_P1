﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PE26A_VVGD_P1
{

    public partial class DlgMesaPrácticas1 : Form
    {
        //Atributos globales para la clase DlgMesaPrácticas1
        int RA;//Renglon Actual
        //Constructor
        public DlgMesaPrácticas1()
        {
            InitializeComponent();
            RA = 0;
        }
        //------------------------------------------------------------------------
        //Genera Matriz para ejercicios de llenado de matrices--------------------
        //------------------------------------------------------------------------
        private void BtnPractica1P1_Click(object sender, EventArgs e)
        {
            int Tamaño;
            int AnchoConstante;
            //------------------------------------------------------------------------
            //Verifica el tamaño de la matriz en campo 1
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura1.Text))
            {
                MessageBox.Show("Capture el tamaño de la matriz");
                TbxCaptura1.Focus();
                return;
            }
            Tamaño = Convert.ToInt32(TbxCaptura1.Text);
            //------------------------------------------------------------------------
            //Verifica el ancho constante de las columnas en campo 2
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura2.Text))
            {
                MessageBox.Show("Capture el  de la matriz");
                TbxCaptura2.Focus();
                return;
            }
            AnchoConstante = Convert.ToInt32(TbxCaptura2.Text);
            //------------------------------------------------------------------------
            //Limpiar Columnas y filas anteriores
            //-----------------------------------------------------------------------
            DgvMatriz1.Columns.Clear();
            DgvMatriz1.Rows.Clear();
            RA = 0;
            //------------------------------------------------------------------------
            //Generar columnas Incrementa y decrementa
            //------------------------------------------------------------------------
            for (int i = 0; i < Tamaño; i++)
            {
                DgvMatriz1.Columns.Add("Col" + i.ToString(), "HC" + i.ToString());
                if (i < (Tamaño / 2))
                {
                    DgvMatriz1.Columns[i].Width = (i * 1) + AnchoConstante;

                }
                else
                {
                    DgvMatriz1.Columns[i].Width = (Tamaño - i) + AnchoConstante;
                }


            }
            //Genera Filas
            for (int r = 0; r < Tamaño; r++) {
                DgvMatriz1.Rows.Add();
            }
            //Final de la funcion de LA PRIMERA practica
        }
        //Determina si la cadena es un valor numerico
        bool EsNumero(string valor)
        {
            int Numero;
            bool Resultado;
            Resultado = int.TryParse(valor, out Numero);
            return Resultado;
        }
        //------------------------------------------------------------------------
        //Funciones de botones para mostrar y ocultar paneles de prácticas--------
        //------------------------------------------------------------------------
        private void BtnPráctica1_Click(object sender, EventArgs e)
        {
            if (PnlPracticas1.Visible)
            {
                PnlPracticas1.Visible = false;
            }
            else
            {
                PnlPracticas1.Visible = true;
                PnlPracticas2.Visible = false;
                PnlPracticas3.Visible = false;
                PnlPracticas4.Visible = false;
            }
        }

        private void BtnPractica2_Click(object sender, EventArgs e)
        {
            if (PnlPracticas2.Visible)
            {
                PnlPracticas2.Visible = false;
            }
            else
            {
                PnlPracticas2.Visible = true;
                PnlPracticas1.Visible = false;
                PnlPracticas3.Visible = false;
                PnlPracticas4.Visible = false;
            }
        }

        private void BtnPractica3_Click(object sender, EventArgs e)
        {
            if (PnlPracticas3.Visible)
            {
                PnlPracticas3.Visible = false;
            }
            else
            {
                PnlPracticas3.Visible = true;
                PnlPracticas1.Visible = false;
                PnlPracticas2.Visible = false;
                PnlPracticas4.Visible = false;
            }
        }

        private void BtnPractica4_Click(object sender, EventArgs e)
        {
            if (PnlPracticas4.Visible)
            {
                PnlPracticas4.Visible = false;
            }
            else
            {
                PnlPracticas4.Visible = true;
                PnlPracticas1.Visible = false;
                PnlPracticas2.Visible = false;
                PnlPracticas3.Visible = false;

            }
        }
        //---------------------------------------------------------------------------------
        //Genera un llenado En l Matriz practica 1, panel 2
        //----------------------------------------------------------------------------------
        private void BtnPractica1P2_Click(object sender, EventArgs e)
        {

            for (int r = 0; r < DgvMatriz1.Rows.Count; r++)
            {
                for (int c = 0; c < DgvMatriz1.Columns.Count; c++)
                {
                    DgvMatriz1.Rows[r].Cells[c].Value = DgvMatriz1.Columns[c].Width;

                    if (c < (DgvMatriz1.Columns.Count / 2))
                    {

                        DgvMatriz1.Rows[r].Cells[c].Style.BackColor = Color.FromArgb(127 + (c * 8), 127 + (c * 8), 127 + (c * 8));
                    }
                    else
                    {
                        DgvMatriz1.Rows[r].Cells[c].Style.BackColor = Color.FromArgb(255 - ((c - 15) * 8), 255 - ((c - 15) * 8), 255 - ((c - 15) * 8));
                    }

                }
            }
        }
        //------------------------------------------------------------------------
        //Boton para generar la practica 3, de la primera practica
        //------------------------------------------------------------------------
        private void BtnPractica1P3_Click(object sender, EventArgs e)
        {
            int r = 0;
            Random Random;
            int ValorRandom;
            Random = new Random();
            while (r < DgvMatriz1.RowCount)
            {
                int c = 0;
                while (c < DgvMatriz1.ColumnCount)
                {
                    ValorRandom = Random.Next(0, 10);

                    DgvMatriz1.Rows[r].Cells[c].Value = ValorRandom;

                    if (ValorRandom == 9)
                    {
                        DgvMatriz1.Rows[r].Cells[c].Style.BackColor = Color.Red;
                    }

                    c++;

                }
                r++;

            }
        }
        //------------------------------------------------------------------------
        //Boton para generar la practica 2, de la primera practica
        //------------------------------------------------------------------------
        private void BtnPractica2P1_Click_1(object sender, EventArgs e)
        {
            int Columnas;
            int Renglones;
            int AnchoConstante;
            int AlturaConstante;
            //------------------------------------------------------------------------
            //Verifica el Numero de columnas en campo 1
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura1.Text))
            {
                MessageBox.Show("Capture el Numero de columnas de la matriz de la matriz");
                TbxCaptura1.Focus();
                return;
            }
            Columnas = Convert.ToInt32(TbxCaptura1.Text);
            //------------------------------------------------------------------------
            //Verifica el Numero de renglones  en campo 2
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura2.Text))
            {
                MessageBox.Show("Capture el Numero de renglones de la matriz");
                TbxCaptura2.Focus();
                return;
            }
            Renglones = Convert.ToInt32(TbxCaptura2.Text);
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura3.Text))
            {
                MessageBox.Show("Capture el Ancho de las columnas matriz");
                TbxCaptura3.Focus();
                return;
            }
            AnchoConstante = Convert.ToInt32(TbxCaptura3.Text);
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura4.Text))
            {
                MessageBox.Show("Capture el ancho de la matriz");
                TbxCaptura4.Focus();
                return;
            }
            AlturaConstante = Convert.ToInt32(TbxCaptura4.Text);
            //------------------------------------------------------------------------

            //------------------------------------------------------------------------
            for (int i = 0; i < Renglones; i++)
            {
                DgvMatriz2.Columns.Add("Col" + i.ToString(), "HC" + i.ToString());
                if (i < (Renglones / 2))
                {
                    DgvMatriz2.Columns[i].Width = (i * 1) + AnchoConstante;

                }
                else
                {
                    DgvMatriz2.Columns[i].Width = (i - i) + AnchoConstante;
                }
            }
        }

        private void BtnPractica2P1_Click(object sender, EventArgs e)
        {
            int Columnas;
            int Renglones;
            int AnchoConstante;
            int AlturaConstante;
            //Verifica el Numero de columnas en campo 1
            if (!EsNumero(TbxCaptura1.Text))
            {
                MessageBox.Show("Capture el Numero de columnas de la matriz de la matriz");
                TbxCaptura1.Focus();
                return;
            }
            Columnas = Convert.ToInt32(TbxCaptura1.Text);
            //Verifica el Numero de renglones  en campo 2
            if (!EsNumero(TbxCaptura3.Text))
            {
                MessageBox.Show("Capture el Numero de renglones de la matriz");
                TbxCaptura3.Focus();
                return;
            }
            Renglones = Convert.ToInt32(TbxCaptura3.Text);
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura2.Text))
            {
                MessageBox.Show("Capture el Ancho de las columnas matriz");
                TbxCaptura2.Focus();
                return;
            }
            AnchoConstante = Convert.ToInt32(TbxCaptura2.Text);
            //------------------------------------------------------------------------
            if (!EsNumero(TbxCaptura4.Text))
            {
                MessageBox.Show("Capture la altura de las columnas matriz");
                TbxCaptura4.Focus();
                return;
            }
            AlturaConstante = Convert.ToInt32(TbxCaptura4.Text);
            //Limpia
            DgvMatriz2.Columns.Clear();
            DgvMatriz2.Rows.Clear();
            RA = 0;
            //-------------------------------------------------------------------------
            //Genera Columnas de practica 2
            for (int i = 0; i < Columnas; i++)
            {
                DgvMatriz2.Columns.Add("Col" + i.ToString(), "HC" + i.ToString());
                DgvMatriz2.Columns[i].Width = AnchoConstante;
                if (CbxCilindro.Checked)
                {
                    if (i < (Columnas / 2))
                    {
                        DgvMatriz2.Columns[i].Width = (i * 1) + AnchoConstante;

                    }
                    else
                    {
                        DgvMatriz2.Columns[i].Width = (Columnas - i) + AnchoConstante;
                    }
                }
                else
                {
                    DgvMatriz2.Columns[i].Width = AnchoConstante;
                }

            }
            for (int r = 0; r < Renglones; r++)
            {
                DgvMatriz2.Rows.Add();
                DgvMatriz2.Rows[r].Height = AlturaConstante;
            }
        }
        //Colorea la matriz Practica2, panel 2
        private void BtnPractica2P2_Click(object sender, EventArgs e)
        {
            for (int r = 0; r < DgvMatriz2.Rows.Count; r++)
            {
                for (int c = 0; c < DgvMatriz2.Columns.Count; c++)
                {
                    int rojo = ((r * c) * 1000) % 256;
                    int verde = ((r + c * 500) % 256);
                    int azul = ((r * 5 + c * 3) % 200) % 256;
                    DgvMatriz2.Rows[r].Cells[c].Style.BackColor =
                        Color.FromArgb(rojo, verde, azul);
                    DgvMatriz2.Rows[r].Cells[c].Value = rojo + "," + verde + "," + azul;


                }
            }
            //Hacer que se coloren las celdas en todos los colores posibles
        }
        
        private void BtnPractica3P2_Click(object sender, EventArgs e)
        {
            int ContadorImpares;
            int ContadorPares;
            int SumaPares = 0;
            int SumaImpares = 0;
            ContadorPares = 0;
            ContadorImpares = 0;
            int ValorRandom;
            RA = 0;
            Random Random;
            Random = new Random();

            for (int r = 0; r < DgvMatriz2.Rows.Count; r++)
            {
                for (int c = 0; c < DgvMatriz2.Columns.Count; c++)
                {
                    ValorRandom = Random.Next(0, 11);

                    if (ValorRandom % 2 == 0)
                    {
                        // Pares
                        DgvMatriz2.Rows[r].Cells[c].Style.BackColor = Color.BlueViolet;
                        TBXCantidadPares.Text = ContadorPares++.ToString();
                        SumaPares += ValorRandom;
                    }
                    else
                    {
                        // impares
                        DgvMatriz2.Rows[r].Cells[c].Style.BackColor = Color.BlanchedAlmond;
                        TBXCantidadImpares.Text = ContadorImpares++.ToString();
                        SumaImpares += ValorRandom;
                    }

                    // Asignar el valor a la celda
                    DgvMatriz2.Rows[r].Cells[c].Value = ValorRandom;
                }
            }

            // Mostrar los resultados de las sumatorias
            SumatoriaPares.Text = SumaPares.ToString();
            SumatoriaImpares.Text = SumaImpares.ToString();
        }
        /// Ordena los digitos de mayor a menor en cada renglon
        private void BtnPractica4P2_Click(object sender, EventArgs e)
        {
            //Saca el valor de numeros de columnas para el ciclo for, y lo asigna a la variable tamaño
            int Tamaño;
            if (!EsNumero(TbxCaptura1.Text))
            {
                MessageBox.Show("Capture el tamaño de la matriz");
                TbxCaptura1.Focus();
                return;
            }
            Tamaño = Convert.ToInt32(TbxCaptura1.Text);
            int x=0;
            for ( x = 0; x < Tamaño; x++)
            {
                for (int c = 0; c < DgvMatriz2.Columns.Count - 1; c++)
                {
                    int Valor1;
                    int Valor2;
                    Valor1 = Convert.ToInt32(DgvMatriz2.Rows[RA].Cells[c].Value);
                    Valor2 = Convert.ToInt32(DgvMatriz2.Rows[RA].Cells[c + 1].Value);
                    if (Valor2 > Valor1)
                    {
                        DgvMatriz2.Rows[RA].Cells[c].Value = Valor2;
                        DgvMatriz2.Rows[RA].Cells[c + 1].Value = Valor1;
                    }

                }

                for (int c = 0; c < DgvMatriz2.Columns.Count; c++)
                {
                    DgvMatriz2.Rows[RA].Cells[c].Style.BackColor = Color.Green;
          
                }
            }
            RA++;
            if (RA == DgvMatriz2.Rows.Count - 1)
            {
                RA = 0;
            }
        }

        private void BtnPractica5P2_Click(object sender, EventArgs e)
        {
            int Tamaño;
            int x;
            int y = 0;
            int AnchoConstante;
            //Numero de Filas
            if (!EsNumero(TbxCaptura1.Text))
            {
                MessageBox.Show("Capture el tamaño de la matriz");
                TbxCaptura1.Focus();
                return;
            }
            Tamaño = Convert.ToInt32(TbxCaptura1.Text);
            //Numero de columnas
            if (!EsNumero(TbxCaptura3.Text))
            {
                MessageBox.Show("Capture el Ancho de las columnas matriz");
                TbxCaptura3.Focus();
                return;
            }
            AnchoConstante = Convert.ToInt32(TbxCaptura3.Text);
            //For para evaluar las columnas
            for (y = 0; y == AnchoConstante; y++)
            {

                for (x = 0; x < Tamaño; x++)
                {
                    for (int c = 0; c < DgvMatriz2.Columns.Count - 1; c++)
                    {
                        int Valor1;
                        int Valor2;
                        Valor1 = Convert.ToInt32(DgvMatriz2.Rows[RA].Cells[c].Value);
                        Valor2 = Convert.ToInt32(DgvMatriz2.Rows[RA].Cells[c + 1].Value);
                        if (Valor2 > Valor1)
                        {
                            DgvMatriz2.Rows[RA].Cells[c].Value = Valor2;
                            DgvMatriz2.Rows[RA].Cells[c + 1].Value = Valor1;
                        }

                    }

                    for (int c = 0; c < DgvMatriz2.Columns.Count; c++)
                    {
                        DgvMatriz2.Rows[RA].Cells[c].Style.BackColor = Color.Green;

                    }
                }
                RA++;
                if (RA == DgvMatriz2.Rows.Count - 1)
                {
                    RA = 0;
                }
            }
        }
    }
}
    